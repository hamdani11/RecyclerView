package hdmn.pam.RecyclerView

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    companion object{
        val INTENT_PARCELABLE = "OBJECT_INTENT"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val superheroList = listOf<Superhero>(
            Superhero(
                R.drawable.bob,
                "Spongebob Squarpants",
                "+62 812 3456 7890" +
                        "\n" +
                        "\nGrup Bikini Bottom" +
                        "\n" +
                        "\nspongebob11@gmail.com" +
                        "\n" +
                        "\nPanggilan Suara Spongebob" +
                        "\n" +
                        "\nPanggilan Vidio Spongebob"

            ),
            Superhero(
                R.drawable.pat,
                "Patrick Star",
                "+62 895 9374 8744" +
                        "\n" +
                        "\nGrup Bikini Bottom" +
                        "\n" +
                        "\nPatrickstar@gmail.com" +
                        "\n" +
                        "\nPanggilan Suara Patrick" +
                        "\n" +
                        "\nPanggilan Vidio Patrick"
            ),
            Superhero(
                R.drawable.wot,
                "Squidward Tentacles",
                "+62 856 5976 3022" +
                        "\n" +
                        "\nGrup Bikini Bottom" +
                        "\n" +
                        "\nartsquidward@gmail.com" +
                        "\n" +
                        "\nPanggilan Suara Squidward" +
                        "\n" +
                        "\nPanggilan Vidio Squidward"
            ),
            Superhero(
                R.drawable.crab,
                "Mr. Crab",
                "+62 898 9366 6300" +
                        "\n" +
                        "\nGrup Bikini Bottom" +
                        "\n" +
                        "\nmrcrabrich@gmail.com" +
                        "\n" +
                        "\nPanggilan Suara Mr. Crab" +
                        "\n" +
                        "\nPanggilan Vidio Mr. Crab"
            ),
            Superhero(
                R.drawable.puff,
                "Mrs. Puff",
                "+62 813 8854 2265" +
                        "\n" +
                        "\nGrup Bikini Bottom" +
                        "\n" +
                        "\nteachmrspuff@gmail.com" +
                        "\n" +
                        "\nPanggilan Suara Mrs. Puff" +
                        "\n" +
                        "\nPanggilan Vidio Mrs. Puff"
            ),
            Superhero(
                R.drawable.garry,
                "Garry",
                "+62 857 0322 9456" +
                        "\n" +
                        "\nGrup Bikini Bottom" +
                        "\n" +
                        "\nmygarry@gmail.com" +
                        "\n" +
                        "\nPanggilan Suara Garry" +
                        "\n" +
                        "\nPanggilan Vidio Garry"
            ),
            Superhero(
                R.drawable.ton,
                "Plankton",
                "+62 884 30034 9675" +
                        "\n" +
                        "\nGrup Bikini Bottom" +
                        "\n" +
                        "\nplankton@gmail.com" +
                        "\n" +
                        "\nPanggilan Suara Plankton" +
                        "\n" +
                        "\nPanggilan Vidio Plankton"
            ),
            Superhero(
                R.drawable.sandy,
                "Sandy Cheeks",
                "+62 833 9845 0587" +
                        "\n" +
                        "\nGrup Bikini Bottom" +
                        "\n" +
                        "\nSandycheeks@gmail.com" +
                        "\n" +
                        "\nPanggilan Suara Sandy Cheeks" +
                        "\n" +
                        "\nPanggilan Vidio Sandy Cheeks"
            )

        )

        val recyclerView = findViewById<RecyclerView>(R.id.rv_hero)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.setHasFixedSize(true)
        recyclerView.adapter = SuperheroAdapter(this, superheroList){
            val intent = Intent (this, DetailSuperheroActivity::class.java)
            intent.putExtra(INTENT_PARCELABLE, it)
            startActivity(intent)

        }


    }
}